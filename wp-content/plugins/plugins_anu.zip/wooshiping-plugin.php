<?php
/*
Plugin Name: wooshiping-plugin
Plugin URI: https://woocommerce.com/
Description: Your shipping method plugin
Version: 1.0.0

*/

/**
 * Check if WooCommerce is active
 */
?>
<?php
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    function your_shipping_method_init()
    {
        if (!class_exists('WC_Your_Shipping_Method')) {
            class WC_Your_Shipping_Method extends WC_Shipping_Method
            {

                public function __construct()
                {

                    $this->id = 'id'; // Id for your shipping method. Should be uunique.
                    $this->title = "Shopping"; // This can be added as an setting but for this example its forced.
                    $this->method_title = __('method_title'); // Title shown in admin
                    $this->method_description = __('The shoppoing description'); // Description shown in admin
                    $this->enabled = "yes"; // This can be added as an setting but for this example its forced enabled
                    $this->init();
                }
                /**
                 * Init your settings
                 *
                 * @access public
                 * @return void
                 */

                function init()
                {
                    // Load the settings API
                    $this->init_form_fields(); // This is part of the settings API. Override the method to add your own settings
                    $this->init_settings(); // This is part of the settings API. Loads settings you previously init.
                    // Save settings in admin if you have any defined
                    add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
                }
                /**
                 * calculate_shipping function.
                 *
                 * @access public
                 * @param mixed $package
                 * @return void
                 */
                public function calculate_shipping($package = array())
                {

                    $all_prods = $package['contents'];
                    $total_prod_weight = 0;
                    foreach ($all_prods as $orederline) {
                        $product_weight = $orederline['data']->weight * $orederline['quantity'];

                        $total_prod_weight += $product_weight;
                    };
                    if ($total_prod_weight < 1) {
                        $cost = 30;
                    } elseif ($total_prod_weight > 1 && $total_prod_weight < 5) {
                        $cost = 60;
                    } elseif ($total_prod_weight > 5 && $total_prod_weight < 10) {
                        $cost = 100;
                    } elseif ($total_prod_weight > 10 && $total_prod_weight < 20) {
                        $cost = 200;
                    } elseif ($total_prod_weight > 20) {
                        $cost = ($total_prod_weight * 10);
                    } else {
                        echo 'Not required';
                    }
                    $rate = array(
                        'id' => $this->id,
                        'label' => $this->title,
                        'cost' => $cost,
                        'calc_tax' => 'per_item'
                    );

                    // Register the rate

                    $this->add_rate($rate);
                }
            }
        }
    }

    add_action('woocommerce_shipping_init', 'your_shipping_method_init');

    function add_your_shipping_method($methods)
    {

        $methods['your_shipping_method'] = 'WC_Your_Shipping_Method';

        return $methods;
    }

    add_filter('woocommerce_shipping_methods', 'add_your_shipping_method');
}
